import { AccountGroupMenuActions } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuActions/AccountGroupMenuActions"
import { ContactSearchPopup } from "../../../pages/gw/generated/billingcenter/pages/popup/Contact/ContactSearchPopup"
import { NewPolicyBillingAPIWizard } from '../../../pages/gw/generated/billingcenter/pages/other/NewPolicyBillingAPIWizard.js';
import { NewPolicyWizardCustom } from "../../../pages/bc/other/NewPolicyWizard"
import { AccountScenarios } from "./AccountScenarios"
import world from "../../../util/bc/world"

const accountGroupMenuActions = new AccountGroupMenuActions();
const contactSearchPopup = new ContactSearchPopup();
const newPolicyBillingAPIWizard = new NewPolicyBillingAPIWizard();
const newPolicyWizardCustom = new NewPolicyWizardCustom();
const accountScenarios = new AccountScenarios();

export class PolicyScenarios {

    async createPolicyOnAccount(accountNumber) {
        await accountScenarios.openAccount(accountNumber);
        let randomNumber = Math.floor( Math.random() * 9999 + 1);
        await accountGroupMenuActions.accountGroupAccountDetailMenuActions.click();
        await accountGroupMenuActions.accountDetailMenuActionsAccountDetailMenuActions_NewPolicyMultiCurrency.click();
        await newPolicyBillingAPIWizard.newPolicyBillingAPIWizardNext.click();
        world.policyNumber = "PA01_" + randomNumber;
        await newPolicyBillingAPIWizard.newPolicyDVPolicyNumber.setValue(world.policyNumber);
        await newPolicyBillingAPIWizard.newPolicyDVPolicyLOB.selectOptionByLabel("Personal Auto");
        await newPolicyBillingAPIWizard.newPolicyDVPaymentPlan.selectOptionByLabel("QA1PAYMENTPLAN01");

        await newPolicyWizardCustom.newPolicyBillingAPIWizardNextDiv.click();
        //await newPolicyBillingAPIWizard.newPolicyBillingAPIWizardNext.click();

        await newPolicyBillingAPIWizard.policyBillingAPIWizardAddChargesLV_tbAdd.click();
        await newPolicyWizardCustom.newPolicyBillingAPIWizardWizardChargeStepScreenPolicyAddChargesListDetailPanelPolicyAddChargesLV_Type.selectOptionByLabel('Premium')
        await newPolicyWizardCustom.newPolicyBillingAPIWizardWizardChargeStepScreenPolicyAddChargesListDetailPanelPolicyAddChargesLV_Amount.setValue("1400");
        await newPolicyBillingAPIWizard.newPolicyBillingAPIWizardFinish.click();
    }

}