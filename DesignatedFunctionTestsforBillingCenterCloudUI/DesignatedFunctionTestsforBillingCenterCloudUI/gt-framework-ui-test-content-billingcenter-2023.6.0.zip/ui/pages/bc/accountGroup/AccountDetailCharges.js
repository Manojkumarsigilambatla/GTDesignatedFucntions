import { PcfCheckBox } from '@gtui/gt-ui-framework';

export class AccountDetailChargesCustom {

    accountDetailChargesAccountDetailChargesScreenAccountDetailChargesListDetailPanelChargesLVCheckbox = PcfCheckBox('#AccountDetailCharges-AccountDetailChargesScreen-AccountDetailChargesListDetailPanel-ChargesLV-_Checkbox_checkboxDiv');

}
