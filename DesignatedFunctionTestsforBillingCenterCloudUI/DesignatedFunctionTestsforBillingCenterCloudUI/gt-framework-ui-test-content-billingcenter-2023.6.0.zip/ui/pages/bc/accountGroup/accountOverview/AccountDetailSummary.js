import { PcfSelectInput } from '@gtui/gt-ui-framework';

export class AccountDetailSummaryCustom {

    accountDetailSummaryAccountDetailSummaryScreenAccountDetailDVDefaultPaymentInstrument = PcfSelectInput("#AccountDetailSummary-AccountDetailSummaryScreen-AccountDetailDV-DefaultPaymentInstrument");

}
