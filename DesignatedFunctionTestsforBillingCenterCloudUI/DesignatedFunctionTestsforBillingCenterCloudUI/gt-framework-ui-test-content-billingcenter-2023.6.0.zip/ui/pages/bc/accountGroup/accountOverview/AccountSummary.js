import { PcfComponent } from '@gtui/gt-ui-framework';

export class AccountSummaryCustom {

    accountSummaryAccountSummaryScreenAccountDetailSummary_DelinquencyAlertAlertBar = PcfComponent("#AccountSummary-AccountSummaryScreen-AccountDetailSummary_DelinquencyAlertAlertBar");

}
