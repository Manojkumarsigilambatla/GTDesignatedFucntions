import { PcfListView, PcfComponent } from '@gtui/gt-ui-framework';

export class AccountDetailInvoicesCustom {

	accountDetailInvoicesAccountDetailInvoicesScreenDetailPanelAccountInvoiceItemsLV = PcfListView('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoiceItemsLV');
	accountDetailInvoicesAccountDetailInvoicesScreen_msgsSelector = PcfComponent('#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs');

}
