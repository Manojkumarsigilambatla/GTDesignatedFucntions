'use strict';
import { AdminScenarios } from "../../../../ui/actions/bc/scenarios/AdminScenarios";
import { DistributionScenarios } from "../../../../ui/actions/bc/scenarios/DistributionScenarios";
const { When } = require('@cucumber/cucumber');
import { t } from "testcafe";

let adminScenarios = new AdminScenarios();
let distributionScenarios = new DistributionScenarios();

When(/^today is the (.*)$/, async function (t, stepArguments) {
    let dateToMoveTo = stepArguments[0];
    await adminScenarios.moveDate(dateToMoveTo);
    const messageSelectorPath = "#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div"
    await distributionScenarios.distributeUnappliedAmount(messageSelectorPath);
});
