import { AccountDetailInvoicesCustom } from "./ScenarioPages/accountGroup/AccountDetailInvoices"
import { InvoiceScenarios } from "./InvoiceScenarios";
import { Selector, t } from "testcafe"
import world from "../../../util/bc/world"
import {retryActionUntil} from "@gtui/gt-ui-framework";

const accountDetailInvoicesCustom = new AccountDetailInvoicesCustom();
const invoiceScenarios = new InvoiceScenarios();

export class AdminScenarios {

    async executeQuickJumpCommand(command) {
        if (await Selector('div#QuickJump').exists && await Selector('div#QuickJump').visible)
            await t.typeText(Selector('div#QuickJump'), command, {replace: true, paste: true }).pressKey('enter');
        else
            await t.typeText(Selector('#QuickJump'), command, {replace: true, paste: true }).pressKey('enter');
    }

    async getCurrentDate() {
        await this.executeQuickJumpCommand("Run Clock");
        return await accountDetailInvoicesCustom.accountDetailInvoicesAccountDetailInvoicesScreen_msgsSelector.component.innerText;
    }

    async moveDate(dateToMoveTo) {
        invoiceScenarios.openInvoices();
        let currentDate = await this.getCurrentDate();
        currentDate = new Date(currentDate);
        let invoiceStatus = dateToMoveTo.toLowerCase().includes("invoice bill date") ? "Planned" : "Billed";

        let invoiceDate = invoiceStatus == ("Planned") ? 
            await invoiceScenarios.getInvoiceBillDate(world.rowNumber) :
            await invoiceScenarios.getInvoiceDueDate(world.rowNumber);
        invoiceDate = new Date(invoiceDate);
        console.log("CurentDate : " + currentDate)
        console.log("Invoice Date : " + invoiceDate)

        let elapsedDays = Math.ceil((invoiceDate - currentDate) / (1000 * 60 * 60 * 24));

        if(dateToMoveTo.includes("- 1"))
            elapsedDays = elapsedDays - 1;
        else if(dateToMoveTo.includes("+ 1"))
            elapsedDays = elapsedDays + 1;

        if(elapsedDays > 0) {
            await this.executeQuickJumpCommand("Run Clock addDays " + (elapsedDays + world.dayOffset));
            world.dayOffset = 0;
            async function actionFunction(){
                //do nothing
            }
            async function comparisonFunction(object){
                let divDate = await object.getCurrentDate();
                divDate = await new Date(divDate);
                return !( divDate.getTime() == currentDate.getTime() );
            }
            await retryActionUntil(actionFunction, comparisonFunction, "Could not find updated date",
                {maxRetry:5, interval:20000, initialDelay: 5000}, [], [this]);
        }

        const messageSelectorPath = "#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div"
        await this.runInvoiceBatchProcesses(messageSelectorPath);
    }

    async runBatchProcessInvoice(messageSelectorPath) {
        await console.log("runBatchProcess Invoice")
        await this.executeQuickJumpCommand("RunBatchProcess Invoice");
        await this.checkCompletedBatchProcess("\"Invoice\"", messageSelectorPath);
    }

    async runBatchProcessInvoiceDue(messageSelectorPath) {
        await console.log("runBatchProcess InvoiceDue")
        await this.executeQuickJumpCommand("RunBatchProcess InvoiceDue");
        await this.checkCompletedBatchProcess("\"InvoiceDue\"", messageSelectorPath);
    }


    async runInvoiceBatchProcesses(messageSelectorPath) {
        await this.runBatchProcessInvoice(messageSelectorPath);
        await this.runBatchProcessInvoiceDue(messageSelectorPath);
    }

    async runBatchProcessPaymentRequest(messageSelectorPath) {
        await console.log("runBatchProcess PaymentRequest")
        await this.executeQuickJumpCommand("RunBatchProcess PaymentRequest");
        await this.checkCompletedBatchProcess("\"PaymentRequest\"", messageSelectorPath);
    }

    async runBatchProcessNewPayment(messageSelectorPath) {
        await console.log("runBatchProcess NewPayment")
        await this.executeQuickJumpCommand("RunBatchProcess NewPayment");
        await this.checkCompletedBatchProcess("\"NewPayment\"", messageSelectorPath);
    }

    async checkCompletedBatchProcess(commandName, messageSelectorPath) {
        await console.log("Check completed batch process: ", commandName);
        async function actionFunction() {
            // do nothing placeholder
        }

        async function comparisonFunction(messageSelectorPath) {
            //let messageSelector = await Selector("#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div");
            let messageSelector = await Selector(messageSelectorPath);
            let messageText = await messageSelector.innerText;
            await console.log(messageText, commandName);
            return messageText.includes(commandName);
        }

        await retryActionUntil(actionFunction, comparisonFunction, `Command: ${commandName} message not there`,
            {maxRetry: 5, interval:10000, initialDelay:1000}, [], [messageSelectorPath]);
    }
}