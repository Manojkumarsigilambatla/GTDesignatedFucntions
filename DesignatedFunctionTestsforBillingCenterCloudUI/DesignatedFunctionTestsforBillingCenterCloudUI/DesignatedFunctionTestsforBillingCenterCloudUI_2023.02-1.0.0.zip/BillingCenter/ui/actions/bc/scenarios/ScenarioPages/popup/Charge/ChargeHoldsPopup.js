import { PcfSelectInput } from '@gtui/gt-ui-framework';

export class ChargeHoldsPopupCustom {

	chargeHoldsPopupChargeHoldsScreenChargesLV0ChargeHoldStatus = PcfSelectInput('#ChargeHoldsPopup-ChargeHoldsScreen-ChargesLV-0-ChargeHoldStatus');
	chargeHoldsPopupChargeHoldsScreenChargesLV1ChargeHoldStatus = PcfSelectInput('#ChargeHoldsPopup-ChargeHoldsScreen-ChargesLV-1-ChargeHoldStatus');

}
