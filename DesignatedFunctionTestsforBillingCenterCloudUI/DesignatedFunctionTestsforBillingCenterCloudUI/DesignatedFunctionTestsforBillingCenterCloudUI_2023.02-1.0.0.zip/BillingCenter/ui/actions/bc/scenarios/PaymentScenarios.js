import { AccountDetailSummary } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountOverview/AccountDetailSummary"
// import { AccountDetailSummaryCustom } from "../scenarios/ScenarioPages/accountGroup/accountOverview/AccountDetailSummary"
import { AccountDetailSummaryCustom } from "./ScenarioPages/accountGroup/accountOverview/AccountDetailSummary"
import { AccountGroupMenuLinks } from "../../../pages/gw/generated/billingcenter/pages//navigation/menuLinks/AccountGroupMenuLinks"
import { AccountPaymentRequests } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountDetailPayments/AccountPaymentRequests"
import { AccountSummary } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountOverview/AccountSummary"
import { NewPaymentInstrumentPopup } from "../../../pages/gw/generated/billingcenter/pages//popup/New/NewPaymentInstrumentPopup"
import { AdminScenarios } from "./AdminScenarios";
import {t} from "testcafe";

const accountDetailSummary = new AccountDetailSummary();
const accountDetailSummaryCustom = new AccountDetailSummaryCustom();
const accountGroupMenuLinks = new AccountGroupMenuLinks();
const accountPaymentRequests = new AccountPaymentRequests();
const accountSummary = new AccountSummary();
const newPaymentInstrumentPopup = new NewPaymentInstrumentPopup();
const adminScenarios = new AdminScenarios();

export class PaymentScenarios {

    async checkPaymentInstrument() {
        await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary.click();

        let paymentMethod = await accountSummary.accountSummaryScreenPaymentMethod.getValue();
        let paymentInstrument;
            if (paymentMethod.includes('ACH/EFT')) {
                paymentInstrument = "EFT/ACH";
            } else if (paymentMethod.includes('Credit Card')) {
                paymentInstrument = "CC";
            } else {
                paymentInstrument = "Responsive";
            }
        return paymentInstrument;
    }

    async addNonResponsiveEFT_ACH() {
        let response = await this.checkPaymentInstrument();
        if (!(response.includes("EFT/ACH"))) {
            await accountDetailSummary.accountDetailSummaryScreenEdit.click();
            await accountDetailSummary.defaultPaymentInstrumentCreateNewPaymentInstrument.click();
            let randomNumber = Math.floor( Math.random() * 999 + 1);
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupPaymentMethod.selectOptionByLabel('ACH/EFT');
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupToken.setValue(randomNumber + 'ACH-EFT');
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupUpdate.click();
            await accountDetailSummary.accountDetailSummaryScreenUpdate.click();
        }
    }

    async addResponsive() {
        let response = await this.checkPaymentInstrument();
        if (!(response.includes("Responsive"))) {
            await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountDetailSummary.click();
            await accountDetailSummary.accountDetailSummaryScreenEdit.click();
            await accountDetailSummaryCustom.accountDetailSummaryAccountDetailSummaryScreenAccountDetailDVDefaultPaymentInstrument.selectOptionByLabel('Responsive');
            await accountDetailSummary.accountDetailSummaryScreenUpdate.click();
        }
    }

    async getPaymentRequestStatus() {
        const messageSelectorPath = "#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div"
        await adminScenarios.runBatchProcessInvoice(messageSelectorPath);
        await accountGroupMenuLinks.menuLinksAccountGroup_AccountDetailPayments.click();
        await accountGroupMenuLinks.accountGroup_AccountDetailPaymentsAccountDetailPayments_AccountPaymentRequests.click();
        let rowCount = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.rowCount();
        let status = '';
        if (rowCount > 0) {
            status = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.getTextFromCell(0,1);
        }
        return status;
    }

    async validatePaymentRequestStatus() {
        await accountGroupMenuLinks.accountGroup_AccountDetailPaymentsAccountDetailPayments_AccountPaymentRequests.click();
        const messageSelectorPath = "#AccountPaymentRequests-AccountDetailPaymentsScreen-_msgs-0-0 > div.gw-message-and-suffix > div";

        await adminScenarios.runBatchProcessPaymentRequest(messageSelectorPath);
        let status = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.getTextFromCell(0,1);
        return status;
    }

}