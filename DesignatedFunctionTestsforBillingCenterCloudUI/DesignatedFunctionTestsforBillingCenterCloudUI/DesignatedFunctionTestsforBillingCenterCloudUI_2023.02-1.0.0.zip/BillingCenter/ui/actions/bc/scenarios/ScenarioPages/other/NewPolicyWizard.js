import {PcfButton, PcfTextInput} from '@gtui/gt-ui-framework';

export class NewPolicyWizardCustom {

	policyAddChargesLV_tbAdd = PcfButton('#NewPolicyWizard-NewPolicyWizardChargeStepScreen-PolicyAddChargesListDetailPanel-PolicyAddChargesLV_tb-Add > div');
	newPolicyWizardNewPolicyWizardChargeStepScreenPolicyAddChargesListDetailPanelPolicyAddChargesLV_Amount = PcfTextInput('#NewPolicyWizard-NewPolicyWizardChargeStepScreen-PolicyAddChargesListDetailPanel-PolicyAddChargesLV-0-Amount');


}
