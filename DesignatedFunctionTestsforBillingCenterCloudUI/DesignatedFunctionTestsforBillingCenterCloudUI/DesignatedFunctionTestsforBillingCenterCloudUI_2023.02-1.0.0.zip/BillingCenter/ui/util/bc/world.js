module.exports = {
    rowNumber: 0,
    accountNumber:'',
    policyNumber:'',
    amtDistributed:'',
    invoiceAmount:0,
    paymentAmount:0,
    dayOffset:0,
    invoiceItem: {
        billDate: ''
    },
    nextPlannedBillDate: ''
};