package pc.api.designatedfunctions;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"features/pc/api"},
        glue = {"gw"},
        plugin = { "html:../reports/apibehaviortests/report.html",
                "json:../reports/apibehaviortests/Cucumber.json",
                "junit:../reports/apibehaviortests/Cucumber.xml" },
        tags = "@add_activity"
)
public class PCAddActivityCucumberScenarioRunner {
}