package pc;

import gw.gtapi.util.Utilities;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class PolicyUtil {
    private static final DateTimeFormatter dtf = ISODateTimeFormat.date();
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private static final int PERSONAL_AUTO_RENEWAL_LEAD_TIME = 45;

    public static String addDaysToISODateString(String dateStr, int numDays) throws ParseException {
        Date date = dtf.parseDateTime(dateStr).toDate();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, numDays);
        return sdf.format(cal.getTime());
    }

    public static int getPersonalAutoRenewalLeadTime() { return PERSONAL_AUTO_RENEWAL_LEAD_TIME; }

    // Random birthday with 25-65 age
    public static String getRandomBirthday() {
        DateTime minDate = new DateTime().minusYears(25);
        DateTime maxDate = new DateTime().minusYears(65);
        int days = Days.daysBetween(maxDate, minDate).getDays();
        LocalDate randomDate = maxDate.plusDays(Utilities.getSecureRandom().nextInt(days+1)).toLocalDate();
        return randomDate.toString();
    }
}
