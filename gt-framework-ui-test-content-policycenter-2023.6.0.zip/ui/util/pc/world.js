module.exports = {
    contact: {
        firstName: "",
        lastName: "",
        name: "",
        taxID: ""
    },
    contactType: "",
    accountNumber: "",
    vehicleVin: "WDDHF8JB3CA549096"
};