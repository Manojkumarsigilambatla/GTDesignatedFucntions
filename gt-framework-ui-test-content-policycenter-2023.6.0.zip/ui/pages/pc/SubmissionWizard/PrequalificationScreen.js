'use strict';
import { PcfSelectInput } from '@gtui/gt-ui-framework';

export class PrequalificationScreen {
    constructor() {
        
        this.currentlyInsuredQuestion = PcfSelectInput("#SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-0-QuestionModalInput-ChoiceSelectInput_NoPost");
    }

    
}