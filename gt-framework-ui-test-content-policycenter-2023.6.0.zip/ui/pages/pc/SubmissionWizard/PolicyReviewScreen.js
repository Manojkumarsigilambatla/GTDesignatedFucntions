'use strict';
import { PcfButton } from '@gtui/gt-ui-framework';

export class PolicyReviewScreen {
    constructor() {
        
        this.quoteButton = PcfButton("#SubmissionWizard-SubmissionWizard_PolicyReviewScreen-JobWizardToolbarButtonSet-QuoteTypeToolbarButtonSet-Quote");
    }
    
}