'use strict';
import { PcfSelectInput } from '@gtui/gt-ui-framework';

export class OfferingScreen {
    constructor() {
        
        this.offeringSelection = PcfSelectInput("#SubmissionWizard-OfferingScreen-OfferingSelection");
    }

}